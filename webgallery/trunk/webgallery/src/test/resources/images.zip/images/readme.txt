All photos are taken by Shaker Cherukuri (http://www.flickr.com/photos/shakercherukuri/). 
Photos are available under Creative Commons Attribute License (http://www.flickr.com/creativecommons/)